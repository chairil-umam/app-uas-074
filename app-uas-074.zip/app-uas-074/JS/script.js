// TRANSAKSI //
function addToCart(itemName) {
  const li = document.createElement("li");
  li.className = "list-group-item fade-slide";
  li.textContent = itemName;
  cartItems.appendChild(li);
}

function prosesPesanan() {
  if (cartItems.children.length === 0) {
    alert("Keranjang masih kosong!");
  } else {
    const items = Array.from(cartItems.children)
      .map((li) => li.textContent)
      .join(", ");
    alert(`Pesanan Anda: ${items}\nTerima kasih telah memesan di Pink Coffee!`);
    cartItems.innerHTML = "";
  }
}

// LOGIN //
function validateLogin(event) {
      event.preventDefault();
      const user = document.getElementById('username').value.trim();
      const pass = document.getElementById('password').value.trim();

      if (!user || !pass) {
        alert("Username dan password tidak boleh kosong.");
        return false;
      }

      localStorage.setItem("username", user);
      alert("Login berhasil! Selamat datang di Pink Coffee ☕");
      window.location.href = "home-074.html";
    }